EDU BRAIN Android V1
====================

Versi awal game edukasi offline untuk Android.

Fitur yang sudah ada:
- Kategori logika, matematika, memori, bahasa, pengetahuan umum, komputer & teknologi.
- Pilihan jenjang Pemula, Menengah, Mahir, Ahli.
- 10 pertanyaan per sesi, skor dan progres tersimpan lokal pada perangkat.
- Tampilan portrait dan antarmuka responsif.

Cara build:
1. Buka proyek ini menggunakan Android Studio.
2. Tunggu Gradle Sync.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).

Catatan:
Ini prototipe V1 yang bisa dimainkan offline. Jenjang saat ini mengubah urutan soal; kurikulum bertingkat, bank soal besar, animasi, dan pengujian perangkat masih perlu dikembangkan.
